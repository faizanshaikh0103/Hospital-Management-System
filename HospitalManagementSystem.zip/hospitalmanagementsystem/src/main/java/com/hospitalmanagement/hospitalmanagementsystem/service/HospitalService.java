package com.hospitalmanagement.hospitalmanagementsystem.service;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.hospitalmanagementsystem.dao.HospitalDao;
import com.hospitalmanagement.hospitalmanagementsystem.entity.Appointment;
import com.hospitalmanagement.hospitalmanagementsystem.entity.Doctors;
import com.hospitalmanagement.hospitalmanagementsystem.entity.Patients;

@Service
public class HospitalService {

	@Autowired
	private HospitalDao dao;
	
	public List<Patients> getpatients(){
		return dao.getpatients();
	}
	
public Patients getPatientbyid(int id) {
		
		return dao.getPatientbyid(id);
	}

	public String insertpatients(Patients p) {
		
		return dao.insertpatients(p);
	}

	public String Updatepatients(Patients p) {
		return dao.Updatepatients(p);
	}

	public String Deletepatients(int id) {
		return dao.Deletepatients(id);
	}
	
}
