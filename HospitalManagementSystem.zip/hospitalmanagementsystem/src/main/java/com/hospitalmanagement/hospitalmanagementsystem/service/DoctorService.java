package com.hospitalmanagement.hospitalmanagementsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.hospitalmanagementsystem.dao.DoctorDao;
import com.hospitalmanagement.hospitalmanagementsystem.entity.Doctors;

@Service
public class DoctorService {

	@Autowired
	private DoctorDao dao;
	
	public List<Doctors> getdoctor(){
		return dao.getdoctor();
	}
	
    public Doctors getDoctorbyid(int id) {
		return dao.getDoctorbyid(id);
	}
    
    public String insertdoctor(Doctors d) {
		return dao.insertdoctor(d);
	}
    
    public String Updatedoctor(Doctors d) {
		return dao.Updatedoctor(d);
	}
    
    public String Deletedoctor(int id) {
		return dao.Deletedoctor(id);
	}
}
