package com.hospitalmanagement.hospitalmanagementsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hospitalmanagement.hospitalmanagementsystem.entity.Doctors;
import com.hospitalmanagement.hospitalmanagementsystem.service.DoctorService;

@RestController
@CrossOrigin
public class DoctorController {

	@Autowired
	private DoctorService service;
	
	@GetMapping("/getdoctors")
	public List<Doctors> getdoctor(){
		return service.getdoctor();
	}
	
	@GetMapping("/doctorbyid/{id}")
	public Doctors getDoctorbyid(@PathVariable int id) {
		return service.getDoctorbyid(id);
	}
	
	@PostMapping("/adddoctor")
	public String insertdoctor(@RequestBody Doctors d) {
		return service.insertdoctor(d);
	}
	
	@PutMapping("/updatedoctor/{id}")
	public String Updatedoctor(@PathVariable int id, @RequestBody Doctors d) {
		d.setId(id);
		return service.Updatedoctor(d);
	}
	
	@DeleteMapping("/deletedoctor/{id}")
	public String Deletedoctor(@PathVariable int id) {
		return service.Deletedoctor(id);
	}
}
