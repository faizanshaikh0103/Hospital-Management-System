package com.hospitalmanagement.hospitalmanagementsystem.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

@Entity
@Component
public class Appointment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name= "patient_id", nullable=false)
	private Patients patients;
	
	@ManyToOne(fetch= FetchType.LAZY)
	@JoinColumn(name= "doctor_id", nullable=false)
	private Doctors doctor;

	@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	private LocalDateTime AppoinmentDateTime;
	private String reason;
	
	//getter and setter
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Patients getPatients() {
		return patients;
	}
	public void setPatients(Patients patients) {
		this.patients = patients;
	}
	public Doctors getDoctor() {
		return doctor;
	}
	public void setDoctor(Doctors doctor) {
		this.doctor = doctor;
	}
	public LocalDateTime getAppoinmentDateTime() {
		return AppoinmentDateTime;
	}
	public void setAppoinmentDateTime(LocalDateTime appoinmentDateTime) {
		this.AppoinmentDateTime = appoinmentDateTime;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	
	@Override
	public String toString() {
		return "Appointment [id=" + id + ", patients=" + patients + ", doctor=" + doctor + ", AppoinmentDateTime="
				+ AppoinmentDateTime + ", reason=" + reason + "]";
	}
	
	
}
