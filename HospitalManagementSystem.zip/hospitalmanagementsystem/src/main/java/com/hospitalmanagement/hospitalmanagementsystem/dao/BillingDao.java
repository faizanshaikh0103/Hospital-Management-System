package com.hospitalmanagement.hospitalmanagementsystem.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hospitalmanagement.hospitalmanagementsystem.entity.Billing;

@Repository
public class BillingDao {

	@Autowired
	private SessionFactory sf;
	@Autowired
	private Billing bill;
	
	public Billing addBill(Billing bill) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Serializable save = session.save(bill);
		tr.commit();
		return session.get(Billing.class, save);
	}
	public List<Billing> getAllBill() {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Billing.class);
		return cr.list();
	}
	public List<Billing> getBillbypatientId(int id) {
		Session session = sf.openSession();
		final String query = "SELECT * FROM billing WHERE patient_id = :id";
		NativeQuery nq = session.createNativeQuery(query);
		return nq.setParameter("id", id).getResultList();
	}
	
	
	public String deleteBill(int pid) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		final String query = "DELETE FROM billing WHERE patient_id = :pid";
		NativeQuery nq = session.createNativeQuery(query);
		nq.setParameter("pid", pid);
		nq.executeUpdate();
		tr.commit();
		return "delete success";
	}
	public String updateBill(Billing bill2) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		bill = session.get(Billing.class, bill2.getId());
		bill.setBillamount(bill2.getBillamount());
		bill.setBilldatetime(bill2.getBilldatetime());
		bill.setDoctor(bill2.getDoctor());
		bill.setPatient(bill2.getPatient());
		bill.setPaymentstatus(bill2.isPaymentstatus());
		session.update(bill);
		tr.commit();
		return "Bill Update Success...";
	}
	
}
