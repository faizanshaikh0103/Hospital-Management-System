package com.hospitalmanagement.hospitalmanagementsystem.controller;

import java.util.List;

import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hospitalmanagement.hospitalmanagementsystem.entity.Appointment;
import com.hospitalmanagement.hospitalmanagementsystem.entity.Doctors;
import com.hospitalmanagement.hospitalmanagementsystem.entity.Patients;
import com.hospitalmanagement.hospitalmanagementsystem.service.HospitalService;

import lombok.Delegate;

@RestController
@CrossOrigin
public class HospitalController {

	@Autowired
	private HospitalService service;
	
	@GetMapping("/getall")
	public List<Patients> getpatients(){
		return service.getpatients();
	}
	
	@GetMapping("/patientbyid/{id}")
	public Patients getPatientbyid(@PathVariable int id) {
		return service.getPatientbyid(id);
	}
	
	@PostMapping("/add")
	public String insertpatients(@RequestBody Patients p) {
		return service.insertpatients(p);
	}
	
	@PutMapping("/update/{id}")
	public String Updatepatient(@PathVariable int id, @RequestBody Patients p) {
		p.setId(id);
		return service.Updatepatients(p);
	}
	
	@DeleteMapping("/delete/{id}")
	public String Deletepatients(@PathVariable int id) {
		return service.Deletepatients(id);
	}

}
