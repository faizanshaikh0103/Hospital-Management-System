package com.hospitalmanagement.hospitalmanagementsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.hospitalmanagementsystem.dao.BillingDao;
import com.hospitalmanagement.hospitalmanagementsystem.entity.Billing;

@Service
public class BillingService {

	@Autowired
	private BillingDao dao;

	public Billing addBill(Billing bill) {
		return dao.addBill(bill);
	}

	public List<Billing> getAllBill() {
		return dao.getAllBill();
	}

	public List<Billing> getBillbypatientId(int id) {
		return dao.getBillbypatientId(id);
	}

	public String deleteBill(int pid) {
		return dao.deleteBill(pid);
	}

	public String updateBill(Billing bill) {
		return dao.updateBill(bill);
	}
}
