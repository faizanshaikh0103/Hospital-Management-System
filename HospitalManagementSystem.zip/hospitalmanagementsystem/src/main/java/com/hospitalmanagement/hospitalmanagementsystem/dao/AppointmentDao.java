package com.hospitalmanagement.hospitalmanagementsystem.dao;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hospitalmanagement.hospitalmanagementsystem.entity.Appointment;

@Repository
public class AppointmentDao {

	@Autowired
	private SessionFactory sf;
	@Autowired
	private Appointment app;
	
	
	public List<Appointment> getAppoinments(){
		Session session = sf.openSession();
		String query= "SELECT appointment.id as appointment_id, appointment.appoinment_date_time, appointment.reason, p.id AS patient_id, CONCAT(p.firstname, ' ', p.lastname) AS patient_name FROM appointment INNER JOIN patients p ON appointment.patient_id = p.id " ; 
				
		NativeQuery nq = session.createNativeQuery(query);
		List<Appointment> resultlist=  nq.getResultList();
			return resultlist;
		}
		
		public List<Appointment> getAppointmentdetail() {
			Session session = sf.openSession();
			String query= "SELECT appointment.id as appointment_id, appointment.appoinment_date_time, appointment.reason, p.id AS patient_id,CONCAT(p.firstname, '', p.lastname) AS patient_name, d.id AS doctor_id, CONCAT(d.firstname, '',d.lastname) AS doctor_name FROM appointment INNER JOIN patients p ON appointment.patient_id = p.id INNER JOIN doctors d ON appointment.doctor_id = d.id";
		    NativeQuery nq = session.createNativeQuery(query);
		    return nq.getResultList();
		   
		}

		public String addAppointment(Appointment ap) {
			Session session = sf.openSession();
			Transaction tr = session.beginTransaction();
			session.save(ap);
			tr.commit();
			return "Appointment done";
		}

		public Appointment getAppointmentbyid(int id) {
			Session session = sf.openSession();
			return session.get(Appointment.class, id);
		}

		public String deleteAppointment(int id) {
			Session session = sf.openSession();
			Transaction tr = session.beginTransaction();
			app = session.get(Appointment.class, id);
			session.delete(app);
			tr.commit();
			return "Appointment Delete Success...";
		}

		public List<Appointment> getAppointmentbyPatientID(int pid) {
			Session session = sf.openSession();
			final String query = "SELECT * FROM appointment where appointment.patient_id = :pid";
			NativeQuery nq = session.createNativeQuery(query);
			nq.setParameter("pid", pid);
			List<Appointment> resultList = nq.getResultList();
			return resultList;
		}
}
