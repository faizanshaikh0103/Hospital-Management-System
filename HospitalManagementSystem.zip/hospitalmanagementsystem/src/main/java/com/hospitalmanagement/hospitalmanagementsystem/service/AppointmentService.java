package com.hospitalmanagement.hospitalmanagementsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.hospitalmanagementsystem.dao.AppointmentDao;
import com.hospitalmanagement.hospitalmanagementsystem.entity.Appointment;

@Service
public class AppointmentService {

	@Autowired
	private AppointmentDao dao;
	
	public List<Appointment> getAppoinments(){
		return dao.getAppoinments();
	}
	
	public List<Appointment> getAppointmentdetail() {
		return dao.getAppointmentdetail();
	}

	public String addAppointment(Appointment ap) {
		return dao.addAppointment(ap);
	}

	public Appointment getAppointmentbyid(int id) {
		return dao.getAppointmentbyid(id);
	}

	public String deleteAppointment(int id) {
		return dao.deleteAppointment(id);
	}

	public List<Appointment> getAppointmentbyPatientID(int pid) {
		return dao.getAppointmentbyPatientID(pid);
	}
}
