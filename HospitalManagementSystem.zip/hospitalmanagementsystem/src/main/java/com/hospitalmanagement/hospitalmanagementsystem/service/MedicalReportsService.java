package com.hospitalmanagement.hospitalmanagementsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.hospitalmanagementsystem.dao.MedicalReportsDao;
import com.hospitalmanagement.hospitalmanagementsystem.entity.MedicalReports;

@Service
public class MedicalReportsService {

	@Autowired
	private MedicalReportsDao dao;
	
	public MedicalReports addReports(MedicalReports report) {
		return dao.addReports(report);
	}

	public List<MedicalReports> getAllReports() {
		return dao.getAllReports();
	}

	public List<MedicalReports> getReportbypatientId(int pid) {
		return dao.getReportbypatientId(pid);
	}

	public String UpdateReport(MedicalReports report) {
		return dao.UpdateReport(report);
	}

	public String deleteReport(int id) {
		return dao.deleteReport(id);
	}

}
