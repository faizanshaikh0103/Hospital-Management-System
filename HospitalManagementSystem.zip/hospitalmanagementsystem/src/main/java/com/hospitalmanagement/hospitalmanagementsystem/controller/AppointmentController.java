package com.hospitalmanagement.hospitalmanagementsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hospitalmanagement.hospitalmanagementsystem.entity.Appointment;
import com.hospitalmanagement.hospitalmanagementsystem.service.AppointmentService;

@RestController
public class AppointmentController {

	@Autowired
	private AppointmentService service;
	
	@GetMapping("/getappdetails")
	public List<Appointment> getAppointmentdetail() {
		return service.getAppointmentdetail();
	}
	
	
	@GetMapping("/getappo")
	public List<Appointment> getAppoinments(){
		return service.getAppoinments();
	}
	
	@GetMapping("/appointmentbyid/{id}")
	public Appointment getAppointmentbyid(@PathVariable int id) {
		return service.getAppointmentbyid(id);
	}
	
	@PostMapping("/addappo")
	public String addAppointment(@RequestBody Appointment ap) {
		return service.addAppointment(ap);
	}
	
	@DeleteMapping("/deleteappo/{id}")
	public String deleteAppointment(@PathVariable int id) {
		return service.deleteAppointment(id);
	}
	
	//get appointment by patient_id
	
	@GetMapping("/getAppobyPatientid/{pid}")
	public List<Appointment> getAppointmentbyPatientID(@PathVariable int pid) {
		return service.getAppointmentbyPatientID(pid);
	}
}
