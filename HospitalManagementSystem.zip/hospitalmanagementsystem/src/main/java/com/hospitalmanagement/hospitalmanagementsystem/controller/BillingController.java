package com.hospitalmanagement.hospitalmanagementsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;import org.springframework.http.converter.feed.AtomFeedHttpMessageConverter;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospitalmanagement.hospitalmanagementsystem.entity.Billing;
import com.hospitalmanagement.hospitalmanagementsystem.service.BillingService;

@RestController
public class BillingController {

	@Autowired
	private BillingService service;
	
	@PostMapping("/addbill")
	public Billing addBill(@RequestBody Billing bill) {
		return service.addBill(bill);
	}
	
	@GetMapping("/getallbill")
	public List<Billing> getAllBill(){
		return service.getAllBill();
	}
	
	@GetMapping("/getbypatientid/{id}")
	public List<Billing> getBillbypatientId(@PathVariable int id){
        return service.getBillbypatientId(id);
	}
	
	@PutMapping("/updatebill/{id}")
	public String updatBill(@PathVariable int id, @RequestBody Billing bill) {
		bill.setId(id);
		return service.updateBill(bill);
	}
	
	@DeleteMapping("/deletebypid/{pid}")
	public String deleteBill(@PathVariable int pid) {
		return service.deleteBill(pid);
	}
}

