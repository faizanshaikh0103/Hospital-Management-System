package com.hospitalmanagement.hospitalmanagementsystem.dao;



import java.util.List;

import javax.print.Doc;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hospitalmanagement.hospitalmanagementsystem.entity.Appointment;
import com.hospitalmanagement.hospitalmanagementsystem.entity.Doctors;
import com.hospitalmanagement.hospitalmanagementsystem.entity.Patients;

@Repository
public class HospitalDao {

	@Autowired
	private SessionFactory sf;
	@Autowired
	private Doctors dd;
	@Autowired
	private Appointment app;
	
	// Patients Table APIs
	
	public List<Patients> getpatients() {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Patients.class);
		return cr.list();
	}
	
	public Patients getPatientbyid(int id) {
		Session session = sf.openSession();
		return session.get(Patients.class, id);
	}

	public String insertpatients(Patients p) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.save(p);
		tr.commit();
		return "Data Saved Success...";
	}

	public String Updatepatients(Patients p) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Patients pt = session.get(Patients.class, p.getId());
		pt.setAddress(p.getAddress());
		pt.setDateofbirth(p.getDateofbirth());
		pt.setEmail(p.getEmail());
		pt.setFirstname(p.getFirstname());
		pt.setGender(p.getGender());
		pt.setLastname(p.getLastname());
		pt.setPhone(p.getPhone());
		session.update(pt);
		tr.commit();
		return "Data Updated Success...";
	}

	public String Deletepatients(int id) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Patients pt = session.get(Patients.class, id);
		session.delete(pt);
		tr.commit();
		return "Delete Success...";
	}

}
