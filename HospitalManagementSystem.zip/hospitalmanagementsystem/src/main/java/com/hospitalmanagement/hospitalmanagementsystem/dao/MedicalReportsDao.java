package com.hospitalmanagement.hospitalmanagementsystem.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hospitalmanagement.hospitalmanagementsystem.entity.MedicalReports;

@Repository
public class MedicalReportsDao {

	@Autowired
	private SessionFactory sf;
	@Autowired
	private MedicalReports mr;
	
	public MedicalReports addReports(MedicalReports report) {
		
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		final String query = "INSERT INTO medical_reports (patient_id, doctor_id, description, recordtype) VALUES (:patient_id,:doctor_id, :description, :recordtype)";
		NativeQuery nq = session.createNativeQuery(query);
		nq.setParameter("patient_id", report.getPatient().getId());
		nq.setParameter("doctor_id", report.getDoctor().getId());
		nq.setParameter("description", report.getDescription());
		nq.setParameter("recordtype", report.getRecordtype());
		int ex = nq.executeUpdate();
		tr.commit();
		return session.get(MedicalReports.class, ex);
	}
	

	public List<MedicalReports> getAllReports() {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(MedicalReports.class);
		return cr.list();
	}

	public List<MedicalReports> getReportbypatientId(int pid) {
		Session session = sf.openSession();
		final String query="SELECT * FROM medical_reports WHERE patient_id = :pid";
		return session.createNativeQuery(query)
				.setParameter("pid", pid)
				.getResultList();
	}


	public String UpdateReport(MedicalReports report) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		mr = session.get(MedicalReports.class, report.getId());
		mr.setDescription(report.getDescription());
		mr.setDoctor(report.getDoctor());
		mr.setPatient(report.getPatient());
		mr.setRecordtype(report.getRecordtype());
		session.update(mr);
		tr.commit();
		return "Update successs...";
	}


	public String deleteReport(int id) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		mr = session.get(MedicalReports.class, id);
		session.delete(mr);
		tr.commit();
		return "Delete Success...";
	}
	
	

}
