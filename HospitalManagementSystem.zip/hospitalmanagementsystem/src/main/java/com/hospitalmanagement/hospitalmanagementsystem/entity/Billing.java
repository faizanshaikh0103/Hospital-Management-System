package com.hospitalmanagement.hospitalmanagementsystem.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Component
public class Billing {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "doctor_id", nullable=false)
	private Doctors doctor;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "patient_id", nullable=false)
	private Patients patient;
	
	private LocalDateTime billdatetime;
	
	private double billamount;
	
	private boolean paymentstatus;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Doctors getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctors doctor) {
		this.doctor = doctor;
	}

	public Patients getPatient() {
		return patient;
	}

	public void setPatient(Patients patient) {
		this.patient = patient;
	}

	public LocalDateTime getBilldatetime() {
		return billdatetime;
	}

	@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	public void setBilldatetime(LocalDateTime billdatetime) {
		this.billdatetime = billdatetime;
	}

	public double getBillamount() {
		return billamount;
	}

	public void setBillamount(double billamount) {
		this.billamount = billamount;
	}

	public boolean isPaymentstatus() {
		return paymentstatus;
	}

	public void setPaymentstatus(boolean paymentstatus) {
		this.paymentstatus = paymentstatus;
	}

	@Override
	public String toString() {
		return "Billing [id=" + id + ", doctor=" + doctor + ", patient=" + patient + ", billdatetime=" + billdatetime
				+ ", billamount=" + billamount + ", paymentstatus=" + paymentstatus + "]";
	}
	
}
