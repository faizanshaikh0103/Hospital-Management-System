package com.hospitalmanagement.hospitalmanagementsystem.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hospitalmanagement.hospitalmanagementsystem.entity.Doctors;

@Repository
public class DoctorDao {

	@Autowired
	private SessionFactory sf;
	@Autowired
	private Doctors dd;
	
	public List<Doctors> getdoctor(){
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Doctors.class);
		return cr.list();
	}
	
	public Doctors getDoctorbyid(int id) {
		Session session = sf.openSession();
		return session.get(Doctors.class, id);
	}
	
	public String insertdoctor(Doctors d) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		dd.setAddress(d.getAddress());
		dd.setDateofbirth(d.getDateofbirth());
		dd.setEmail(d.getEmail());
		dd.setExperience(d.getExperience());
		dd.setFirstname(d.getFirstname());
		dd.setGender(d.getGender());
		dd.setLastname(d.getLastname());
		dd.setPhone(d.getPhone());
		dd.setSpecialization(d.getSpecialization());
		session.save(dd);
		tr.commit();
		return "Doctor Added success...";
	}
	
	public String Updatedoctor(Doctors d) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		dd = session.get(Doctors.class, d.getId());
		dd.setAddress(d.getAddress());
		dd.setDateofbirth(d.getDateofbirth());
		dd.setEmail(d.getEmail());
		dd.setExperience(d.getExperience());
		dd.setFirstname(d.getFirstname());
		dd.setGender(d.getGender());
		dd.setLastname(d.getLastname());
		dd.setPhone(d.getPhone());
		dd.setSpecialization(d.getSpecialization());
		session.update(dd);
		tr.commit();
		return "Doctor Update Success...";
	}
	
	public String Deletedoctor(int id) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		dd = session.get(Doctors.class, id);
		session.delete(dd);
		tr.commit();
		return "Doctor Record Deleted Success...";
	}
}
